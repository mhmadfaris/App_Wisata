@extends('wisatas.layout')

@section('content')

<form action="{{ route('wisatas.update', $wisata->id) }}" method="post" enctype="multipart/form-data" class="form">
@csrf
@method('PUT')

<label for="">name</label><br>
<input type="text" name="nama" id="" value="{{ $wisata->nama }}"><br>

<label for="">kota</label><br>
<input type="text" name="kota" id="" value="{{ $wisata->kota }}"><br>

<label for="">hargatiket</label><br>
<input type="text" name="hargatiket" id="" value="{{ $wisata->hargatiket }}"><br>

<label for="">upload image</label><br>
<input type="file" name="image" id=""><br><br>

<input type="submit" value="update">


</form>
    
@endsection