@extends('wisatas.layout')

@section('content')

<a href="{{ route('wisatas.create')}}" class="btn btn-primary">Add New</a>

<table class="table">
    <tr>
        <th>ID</th>
        <th>nama</th>
        <th>kota</th>
        <th>hargatiket</th>
        <th>image</th>
        <th>action</th>
    </tr>

    @foreach ($wisatas as $wisata)
    <tr>
        <td>{{ $wisata->id }}</td>
        <td>{{ $wisata->nama }}</td>
        <td>{{ $wisata->kota }}</td>
        <td>{{ $wisata->hargatiket }}</td>
        <td >
            <img src="{{ Storage::url('public/images/').$wisata->image }}" class="rounded" style="width: 90px">
        </td>
        <td>
            <a href="{{ route('wisatas.show', $wisata->id) }}" class="btn btn-success">show</a>
            <a href="{{ route('wisatas.edit', $wisata->id) }}" class="btn btn-warning">edit</a>

            <form onclick="return confirm('are you sure')" action="{{ route('wisatas.destroy', $wisata->id) }}" method="post" style="display: inline;">
            @csrf
            @method('DELETE')
            <button class="btn btn-danger">Hapus</button>
        </form>
        </td>
    </tr>
        
    @endforeach
</table>

{{ $wisatas->links() }}
    
@endsection