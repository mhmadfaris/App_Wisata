<?php $__env->startSection('content'); ?>

<form action="<?php echo e(route('wisatas.store')); ?>" method="post" enctype="multipart/form-data" class="form">
    <?php echo csrf_field(); ?>

    <label for="">nama</label><br>
    <input type="text" name="nama" id=""><br>

    <label for="">kota</label><br>
    <input type="text" name="kota" id=""><br>

    <label for="">hargatiket</label><br>
    <input type="number" name="hargatiket" id=""><br>

    <label for="">upload image</label><br>
    <input type="file" name="image" id=""><br><br>

    <input type="submit" value="save">

</form>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('wisatas.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siswa/app_wisata/resources/views/wisatas/create.blade.php ENDPATH**/ ?>