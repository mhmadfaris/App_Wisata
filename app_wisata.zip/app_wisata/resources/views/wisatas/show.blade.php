@extends('wisatas.layout')

@section('content')

<img src="{{ Storage::url('public/images/' . $wisata->image) }}" alt="" style="width: 150px"><br>

<h3>{{ $wisata->name }}</h3>
<p>{{ $wisata->kota }}</p>
<p>{{ $wisata->hargatiket }}</p>

<a href="{{ route('wisatas.index') }}" class="btn btn-secondary">back to index</a>
    
@endsection