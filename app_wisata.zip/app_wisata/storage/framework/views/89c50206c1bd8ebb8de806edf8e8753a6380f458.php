<?php $__env->startSection('content'); ?>

<a href="<?php echo e(route('wisatas.create')); ?>" class="btn btn-primary">Add New</a>

<table class="table">
    <tr>
        <th>ID</th>
        <th>nama</th>
        <th>kota</th>
        <th>hargatiket</th>
        <th>image</th>
        <th>action</th>
    </tr>

    <?php $__currentLoopData = $wisatas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wisata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($wisata->id); ?></td>
        <td><?php echo e($wisata->nama); ?></td>
        <td><?php echo e($wisata->kota); ?></td>
        <td><?php echo e($wisata->hargatiket); ?></td>
        <td >
            <img src="<?php echo e(Storage::url('public/images/').$wisata->image); ?>" class="rounded" style="width: 90px">
        </td>
        <td>
            <a href="<?php echo e(route('wisatas.show', $wisata->id)); ?>" class="btn btn-success">show</a>
            <a href="<?php echo e(route('wisatas.edit', $wisata->id)); ?>" class="btn btn-warning">edit</a>

            <form onclick="return confirm('are you sure')" action="<?php echo e(route('wisatas.destroy', $wisata->id)); ?>" method="post" style="display: inline;">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button class="btn btn-danger">Hapus</button>
        </form>
        </td>
    </tr>
        
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

<?php echo e($wisatas->links()); ?>

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('wisatas.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siswa/app_wisata/resources/views/wisatas/index.blade.php ENDPATH**/ ?>