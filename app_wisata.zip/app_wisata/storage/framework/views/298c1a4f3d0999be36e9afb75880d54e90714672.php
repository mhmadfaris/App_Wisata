<?php $__env->startSection('content'); ?>

<img src="<?php echo e(Storage::url('public/images/' . $wisata->image)); ?>" alt="" style="width: 150px"><br>

<h3><?php echo e($wisata->name); ?></h3>
<p><?php echo e($wisata->kota); ?></p>
<p><?php echo e($wisata->hargatiket); ?></p>

<a href="<?php echo e(route('wisatas.index')); ?>" class="btn btn-secondary">back to index</a>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('wisatas.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siswa/app_wisata/resources/views/wisatas/show.blade.php ENDPATH**/ ?>