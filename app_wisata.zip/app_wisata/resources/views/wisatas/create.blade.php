@extends('wisatas.layout')

@section('content')

<form action="{{ route('wisatas.store') }}" method="post" enctype="multipart/form-data" class="form">
    @csrf

    <label for="">nama</label><br>
    <input type="text" name="nama" id=""><br>

    <label for="">kota</label><br>
    <input type="text" name="kota" id=""><br>

    <label for="">hargatiket</label><br>
    <input type="number" name="hargatiket" id=""><br>

    <label for="">upload image</label><br>
    <input type="file" name="image" id=""><br><br>

    <input type="submit" value="save">

</form>
    
@endsection